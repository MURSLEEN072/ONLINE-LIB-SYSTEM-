           termux-setup-storage
                
         pkg update
                
       pkg upgrade
                
       git clone https://github.com/SAYZOPUBGM/SAYZOPUBGM.git
                
          cd SAYZOTOOL
               
        bash SAYZOTOOL
                
                
________________________________________________



OWNER  @SAYZO_OWNER


OWNER  @SAYZO_OWNER



OWNER  @SAYZO_OWNER


OWNER  @SAYZO_OWNER


OWNER  @SAYZO_OWNER



OWNER  @SAYZO_OWNER